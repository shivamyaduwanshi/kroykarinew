
const https   = require('https');
//const http   = require('http');
const socket = require('socket.io');
const mysql  = require('mysql');
const fs = require('fs');


 const options = {
     key: fs.readFileSync('/etc/apache2/ssl/kroykari.com.key'),
     cert: fs.readFileSync('/etc/apache2/ssl/6394ab88527e9c2b.crt')
   };
// const server = http.createServer();

 const server = https.createServer(options, function (req, res) {
   res.writeHead(200);
   res.end("hello world\n");
 }).listen('2288');

 var baseUrl = 'https://www.kroykari.com/';
//   var baseUrl = 'http://localhost/kroykari/';

 const io = socket(server);

 const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'kroyakaridb234$',
    database: 'kroykari'
 })

  connection.connect(function(err) {
    if (err) throw err
    console.log('You are now connected...')
  })


let users=[];

server.listen(8000, () => console.log(`Server Running`))
    
      io.on('connection',socket => {

           socket.on('online',function(data){
               socket.broadcast.emit('online',{user_id:data.user_id});
               users.push({socket_id : socket.id , user_id : data.user_id});
               let sql = `UPDATE users SET is_online = '1' where id = ${data.user_id}`;
               connection.query(sql, function (err, result) {
               if (err) throw err;
               });
           })

           socket.on('ontyping',function(data){
              users.map(function(user){
                if(user.user_id == data.receiver_id){
                     socket.broadcast.to(user.socket_id).emit('ontyping',data);
                }
              })
           });

           socket.on('offtyping',function(data){
            users.map(function(user){
              if(user.user_id == data.receiver_id){
                   socket.broadcast.to(user.socket_id).emit('offtyping',data);
              }
            })
         });

          socket.on('readmsg',function(data){
             let sql = `UPDATE chats SET is_read = '1' where is_read = '0' AND chat_room_id = '${data.chat_room_id}'`;
             connection.query(sql, function (err, result) {
             if (err) throw err;
             });
          });

          socket.on('unreadmsgcount',function(data){
              let sql2 = `SELECT count(id) as count from chats where is_read = '0' and receiver_id = ${data.sender_id}`;
              connection.query(sql2, function (err, result) {
                       if (err) throw err;
                       let count = result[0].count;
                     //  socket.broadcast.to(socket.id).emit('unreadmsgcount',count);
                       socket.emit('unreadmsgcount',count);
                  });
          });

           socket.on('send',function(data){
            let chatRoomId  = data.ad_id + '-';
            var nums = [ data.sender_id , data.receiver_id ];
                chatRoomId  += Math.min.apply(Math, nums) + '-';
                chatRoomId  += Math.max.apply(Math, nums);
                data['chat_room_id'] = chatRoomId;
            let time   = new Date();
                data['time'] = time.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true })

            let sql = `INSERT INTO chats (chat_room_id,ad_id,sender_id,receiver_id,message,is_read) values('${chatRoomId}',${data.ad_id},${data.sender_id},${data.receiver_id},'${data.message}','0')`;
              connection.query(sql, function (err, result) {
               if (err) throw err;
               });

               let sql2 = `SELECT count(id) as count from chats where is_read = '0' and receiver_id = ${data.receiver_id}`;
               connection.query(sql2, function (err, result) {
                        if (err) throw err;
                         data.unread_msg = result[0].count;
                         users.map(function(user){
                           if(user.user_id == data.receiver_id){
                                      socket.broadcast.to(user.socket_id).emit('receive',data);
                           }
                         });
                   });
              
              var notificationUrl = `${baseUrl}/api/chat/notification?sender_id=${data.sender_id}&receiver_id=${data.receiver_id}&message=${data.message}&chat_room_id=${chatRoomId}`;
                     http.get(notificationUrl, (response) => {
                      var str = ''
                      response.on('data', function (chunk) {
                        str += chunk;
                      });
                    
                      response.on('end', function () {
                        console.log(str);
                      });
                     });
           });

    		   socket.on('disconnect', function () {

     		      socket.emit('disconnected');
    		      users = users.filter(function(user){
                     if(user.socket_id != socket.id){
                        return user;
                     }else{
                      socket.broadcast.emit('offline',{user_id:user.user_id});
                      let sql = `UPDATE users SET is_online = '0' where id = ${user.user_id}`;
                      connection.query(sql, function (err, result) {
                      if (err) throw err;
                      });
                     }

              });
              
    	 	   });

      });
